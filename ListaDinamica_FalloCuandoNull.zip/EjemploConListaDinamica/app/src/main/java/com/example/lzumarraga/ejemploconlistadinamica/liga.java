package com.example.lzumarraga.ejemploconlistadinamica;

public enum liga {

    PRIMERA, SEGUNDA, SEGUNDA_B

}
