package com.luisz.simpleclicker.Util;

import android.view.View;

public interface RecyclerViewOnClickListener {
    void onClick(View v, int position);
}
