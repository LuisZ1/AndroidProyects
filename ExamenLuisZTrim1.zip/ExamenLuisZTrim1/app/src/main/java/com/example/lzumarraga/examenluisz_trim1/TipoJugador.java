package com.example.lzumarraga.examenluisz_trim1;

public enum TipoJugador {

    FUTBOL, BALONCESTO

}
